package com.example.crudfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class showAllActivity extends AppCompatActivity {
    dbo obj = new dbo(this,null,null,1);
    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);
        ListView lv;
        List<String> ls=new ArrayList<>();
        lv=findViewById(R.id.lv1);

        Cursor c;
        c=obj.get_Data();
        if(c != null && !c.isClosed())
        {
            c.moveToFirst();
            do{
                ls.add(c.getString(c.getColumnIndex("ename")).toString());
            }while (c.moveToNext());
            ArrayAdapter<String> adp=new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, ls);
            lv.setAdapter(adp);
        }
        else
        {
            Toast.makeText(getApplicationContext(),"No Data", Toast.LENGTH_LONG).show();
        }

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                Intent intent = new Intent(showAllActivity.this,UpdateActivity.class);
                intent.putExtra("Data",ls.get(position));
                startActivity(intent);
            }
        });
    }
}