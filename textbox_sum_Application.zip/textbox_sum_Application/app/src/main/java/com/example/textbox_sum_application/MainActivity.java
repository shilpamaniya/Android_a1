package com.example.textbox_sum_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


        EditText fname;
        EditText lname;
        Button add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fname= findViewById(R.id.fname);
        lname=findViewById(R.id.lname);
        add=findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

                String str=("welcome\n" +fname.getText().toString()+""+ lname.getText().toString());
                Intent it=new Intent(getApplicationContext(),second_MainActivity2.class);
                it.putExtra("message_key",str);
                startActivity(it);
            }
        });

    }
}