package com.example.color_userinterface;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

public class Color_MainActivity extends AppCompatActivity {
Button btn,btn2,btn3,btn4,btn5,btn6,btn7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_main);
        btn=findViewById(R.id.btn1);
        btn.setBackgroundColor(Color.RED);
        btn3=findViewById(R.id.btn2);
        btn3.setBackgroundColor(Color.rgb(255,165,0));
        btn2=findViewById(R.id.btn3);
        btn2.setBackgroundColor(Color.YELLOW);
        btn4=findViewById(R.id.btn4);
        btn4.setBackgroundColor(Color.GREEN);
        btn5=findViewById(R.id.btn);
        btn5.setBackgroundColor(Color.BLUE);
        btn6=findViewById(R.id.btn5);
        btn6.setBackgroundColor(Color.rgb(75,0,175));
        btn7=findViewById(R.id.btn6);
        btn7.setBackgroundColor(Color.rgb(238,130,238));




    }

}